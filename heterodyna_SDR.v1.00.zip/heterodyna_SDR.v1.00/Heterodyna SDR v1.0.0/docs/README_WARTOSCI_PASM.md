# Heterodyna SDR Scanner PRO — zalecane wartości sterowania

## Szybkie ustawienia startowe

| Pasmo / zastosowanie | Modulacja | Częstotliwość / zakres | Gain | Squelch | Sample rate | Output rate | LP Hz | HP Hz | Noise gate | AGC audio |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| PMR 446 | NFM | 446.00625–446.19375 MHz | 30–40 | 3–7 | 48000 | 48000 | 3000–3500 | 120–180 | 1–3 | ON |
| Lotnictwo VHF | AM | 118–137 MHz | 35–45 | 0–4 | 48000 | 48000 | 4000–5000 | 80–150 | 0–2 | ON |
| Radio FM | WFM | 87.5–108 MHz | 15–30 | 0 | 1024000–2048000 | 48000 | 15000 | 30–80 | 0 | ON |
| NOAA/Meteor legacy | WFM | 137–138 MHz | 35–45 | 0–3 | 1024000 | 48000 | 15000 | 30–80 | 0 | ON |
| ADS-B | raw/rtl_adsb | 1090 MHz | 35–45 | 0 | 2048000 | — | — | — | — | OFF |
| CB okolice 27 MHz | AM/USB/LSB | 26–28 MHz | 35–45 | 0–5 | 48000 | 48000 | 3000–5000 | 80–180 | 1–3 | ON |
| APRS | NFM | 144.800 MHz | 30–40 | 2–6 | 48000 | 48000 | 3000 | 120 | 1–2 | ON |
| AIS | NFM | 161.975 / 162.025 MHz | 35–45 | 2–6 | 48000 | 48000 | 3000 | 120 | 1–2 | ON |

## Co oznaczają parametry

### Gain
Wzmocnienie odbiornika.  
Za mały gain = cicho i słaby sygnał.  
Za duży gain = szum, przester, pisk, fałszywe sygnały.

Start:
- blisko nadajnika: 15–25
- normalnie: 30–35
- słaby sygnał: 40–45

### Squelch
Próg otwarcia audio/skanera.
- 0 = wszystko słychać, dużo szumu
- 3–6 = dobry start dla PMR/NFM
- 7–10 = mniej fałszywych otwarć
- 11+ = tylko mocne sygnały

### Sample rate
Ile próbek odbiornik pobiera.
- 48000 = stabilne dla audio NFM/AM
- 1024000 = dobry start dla FFT/IQ
- 2048000 = szerzej, ale większe obciążenie

### Output rate
Częstotliwość audio.
- 48000 = zalecane
- 22050 = oszczędnie, gdy komputer tnie

### LP Hz / HP Hz
Filtry audio.
- LP ucina wysokie piski
- HP ucina buczenie/niskie dudnienie

Dla głosu:
- LP 3000–3500
- HP 120–180

### Noise gate
Bramka szumów.
- 0 = wyłączona
- 1–3 = lekko
- 4–6 = mocniej, ale może ucinać ciche rozmowy

### AGC audio
Wyrównanie głośności. Zalecane ON.
- target: -18 dBFS
- min: 20%
- max: 100%

Jeśli nadal za głośno: max 70–80%.
Jeśli za cicho: min 30–40%.
