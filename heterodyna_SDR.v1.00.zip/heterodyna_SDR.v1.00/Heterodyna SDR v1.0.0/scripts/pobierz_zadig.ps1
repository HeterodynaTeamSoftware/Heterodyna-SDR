# Heterodyna SDR Scanner - pobieranie Zadig / WinUSB
# Fallbacki:
# 1) oficjalny bezposredni link zadig-2.9.exe
# 2) parser katalogu https://zadig.akeo.ie/downloads/
# 3) winget
# 4) otwarcie strony w przegladarce

$ErrorActionPreference = "Continue"

$base = Split-Path -Parent $PSScriptRoot
$drivers = Join-Path $base "drivers"
New-Item -ItemType Directory -Force -Path $drivers | Out-Null

$zadig = Join-Path $drivers "zadig.exe"

function Test-ZadigFile {
    param([string]$Path)
    return ((Test-Path $Path) -and ((Get-Item $Path).Length -gt 1000000))
}

function Try-Download {
    param([string]$Url)
    Write-Host "Probuje: $Url"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $Url -OutFile $zadig -UseBasicParsing -Headers @{ "User-Agent" = "HeterodynaSDRScanner" }
        if (Test-ZadigFile $zadig) {
            Write-Host "OK: $zadig"
            return $true
        }
    }
    catch {
        Write-Host "Nie udalo sie: $($_.Exception.Message)"
    }
    return $false
}

Write-Host "Pobieranie Zadig / WinUSB..."
Write-Host "Folder drivers: $drivers"

if (Try-Download "https://zadig.akeo.ie/downloads/zadig-2.9.exe") {
    Write-Host "Gotowe."
    exit 0
}

try {
    $indexUrl = "https://zadig.akeo.ie/downloads/"
    Write-Host "Czytam katalog: $indexUrl"
    $html = (Invoke-WebRequest -Uri $indexUrl -UseBasicParsing -Headers @{ "User-Agent" = "HeterodynaSDRScanner" }).Content

    $matches = [regex]::Matches($html, 'zadig-[0-9]+(?:\.[0-9]+)*\.exe') |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique

    foreach ($m in ($matches | Sort-Object -Descending)) {
        if (Try-Download ($indexUrl + $m)) {
            Write-Host "Gotowe."
            exit 0
        }
    }
}
catch {
    Write-Host "Parser katalogu nie zadzialal: $($_.Exception.Message)"
}

try {
    Write-Host "Probuje winget..."
    winget install --id akeo.ie.Zadig -e --accept-package-agreements --accept-source-agreements
    Write-Host "Winget zakonczyl prace. Uruchom Zadig z Menu Start albo kliknij Strona Zadig."
    exit 0
}
catch {
    Write-Host "Winget nie zadzialal: $($_.Exception.Message)"
}

Write-Host "Otwieram oficjalna strone Zadig..."
Start-Process "https://zadig.akeo.ie/"
Write-Host "Pobierz zadig-*.exe recznie. Program znajdzie go w Downloads albo Desktop po kliknieciu Uruchom Zadig."
