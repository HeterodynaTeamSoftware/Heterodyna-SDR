# Czyści stare zagnieżdżone projekty i katalogi builda, które mogą mieszać kompilację.
# Uruchom w folderze projektu:
# powershell -ExecutionPolicy Bypass -File .\scripts\wyczysc_stare_foldery.ps1

$root = Split-Path -Parent $PSScriptRoot
Write-Host "Projekt: $root"

Get-ChildItem -Path $root -Directory -Filter "HeterodynaSDRScanner_v*" | ForEach-Object {
    Write-Host "Usuwam stary zagnieżdżony folder: $($_.FullName)"
    Remove-Item $_.FullName -Recurse -Force
}

Get-ChildItem -Path $root -Directory -Filter "bin" | ForEach-Object {
    Write-Host "Usuwam: $($_.FullName)"
    Remove-Item $_.FullName -Recurse -Force
}

Get-ChildItem -Path $root -Directory -Filter "obj" | ForEach-Object {
    Write-Host "Usuwam: $($_.FullName)"
    Remove-Item $_.FullName -Recurse -Force
}

Write-Host "Gotowe."
