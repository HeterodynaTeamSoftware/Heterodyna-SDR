# Heterodyna SDR Scanner - pobieranie narzędzi RTL-SDR
$ErrorActionPreference = "Stop"

$base = Split-Path -Parent $PSScriptRoot
$tools = Join-Path $base "tools\rtl_fm"
$tmpDir = Join-Path $env:TEMP "heterodyna-rtl-sdr-tools"
$zip = Join-Path $tmpDir "rtl-sdr-blog-release.zip"

New-Item -ItemType Directory -Force -Path $tools | Out-Null
Remove-Item -Force -Recurse $tmpDir -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

Write-Host "Folder tools: $tools"
Write-Host "Pobieranie informacji o najnowszym wydaniu RTL-SDR Blog..."

$api = "https://api.github.com/repos/rtlsdrblog/rtl-sdr-blog/releases/latest"
$release = Invoke-RestMethod -Uri $api -Headers @{ "User-Agent" = "HeterodynaSDRScanner" }

$asset = $release.assets | Where-Object {
    $_.name -match "\.zip$" -and ($_.name -match "win|windows|release|x64|x86|rtl")
} | Select-Object -First 1

if (-not $asset) {
    Write-Host "Nie znaleziono ZIP w assets. Lista assets:"
    $release.assets | ForEach-Object { Write-Host $_.name }
    throw "Brak pasującej paczki ZIP."
}

Write-Host "Pobieram: $($asset.name)"
Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zip -Headers @{ "User-Agent" = "HeterodynaSDRScanner" }

Write-Host "Rozpakowywanie..."
Expand-Archive -Path $zip -DestinationPath $tmpDir -Force

$needed = @("rtl_fm.exe", "rtl_test.exe", "rtlsdr.dll", "libusb-1.0.dll", "pthreadVC2.dll", "libwinpthread-1.dll", "msvcr100.dll")

foreach ($n in $needed) {
    $found = Get-ChildItem -Path $tmpDir -Recurse -Filter $n -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) {
        Copy-Item $found.FullName -Destination (Join-Path $tools $n) -Force
        Write-Host "OK: $n"
    } else {
        Write-Host "Opcjonalnie/brak: $n"
    }
}

Write-Host ""
Write-Host "Gotowe. Wróć do programu i kliknij: Sprawdź narzędzia."
Write-Host "Jeżeli test SDR dalej nie wykryje urządzenia, trzeba zainstalować sterownik WinUSB przez Zadig."
