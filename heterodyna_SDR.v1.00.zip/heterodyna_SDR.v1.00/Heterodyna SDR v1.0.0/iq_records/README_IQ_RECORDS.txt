Tu program zapisuje surowe próbki IQ: unsigned 8-bit interleaved I,Q,I,Q (.u8.iq).
