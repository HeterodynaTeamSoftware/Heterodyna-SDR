Tutaj program zapisuje nagrania WAV.
