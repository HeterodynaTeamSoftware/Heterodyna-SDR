Sterownik USB dla RTL-SDR instalujesz zwykle przez Zadig/WinUSB. Docelowo dodamy przycisk naprawy sterownika.
