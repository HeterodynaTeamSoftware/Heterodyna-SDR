Naprawa usb_claim_interface error -12:

1. Zamknij SDR++, SDR#, HDSDR, CubicSDR i inne programy SDR.
2. Uruchom Zadig jako administrator.
3. Options -> List All Devices.
4. Wybierz Bulk-In Interface (0), RTL2832U, RTL2838UHIDIR albo RTL-SDR.
5. Ustaw Driver: WinUSB.
6. Kliknij Replace Driver / Install Driver.
7. Odłącz i podłącz RTL-SDR.
8. W programie kliknij Test SDR.

Nie wybieraj Interface 1 / IR / HID.
