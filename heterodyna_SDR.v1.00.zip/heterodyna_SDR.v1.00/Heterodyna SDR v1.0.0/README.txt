Heterodyna SDR Scanner PRO HeterodynaSDRScanner_v01.001.0062

WAŻNE — STRUKTURA ZIP:
Ten ZIP nie zawiera dodatkowego folderu w środku.
Po rozpakowaniu do folderu HeterodynaSDRScanner_v01.001.0062 plik .csproj jest od razu w tym folderze.

NOWE:
- A) realne audio: rtl_fm.exe -> stdout PCM -> NAudio -> głośnik
- B) auto-scan kanałów z prostym wykrywaniem aktywności po poziomie audio
- C) obsługa USB i LSB w UI oraz komendach rtl_fm
- PackageReference NAudio 2.2.1
- pliki data/tools/scripts kopiują się do build/publish

KOMPILACJA:
cd C:\Users\adria\Downloads\HeterodynaSDRScanner_v01.001.0062
dir *.csproj
dotnet restore
dotnet build -c Release
dotnet run

PUBLIKACJA EXE:
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true

EXE:
bin\Release\net8.0-windows\win-x64\publish\HeterodynaSDRScanner.exe

NARZĘDZIA RTL-SDR:
1. Uruchom program.
2. Zakładka Narzędzia / sterownik.
3. Kliknij Pobierz narzędzia RTL-SDR.
4. Kliknij Sprawdź narzędzia.
5. Kliknij Test SDR.
6. Jeśli urządzenia nie wykrywa, ustaw WinUSB przez Zadig.


POPRAWKA v01.001.0062:
- v0014 i v0015 pomijamy.
- v0016 jest zbudowana od czystej bazy v0011.
- Nie rusza MainWindow.xaml.cs poza zmianą numeru wersji.
- Poprawiony jest skrypt pobierania Zadig: oficjalny katalog downloads + fallback winget.


POPRAWKA v01.001.0062:
- Naprawiono problem duplikatów kompilacji, gdy w folderze projektu leżą stare foldery wersji.
- .csproj ma teraz EnableDefaultItems=false i jawnie wskazuje tylko:
  App.xaml, App.xaml.cs, MainWindow.xaml, MainWindow.xaml.cs
- Dodano skrypt: scripts/wyczysc_stare_foldery.ps1

KOMPILACJA:
cd C:\Users\adria\Desktop\HeterodynaSDRScanner_v01.001.0062
dir *.csproj
dotnet clean
dotnet restore
dotnet build -c Release
dotnet run


POPRAWKA v01.001.0062:
- Program rozpoznaje usb_claim_interface error -12 i pokazuje konkretną naprawę sterownika.
- Dodano przyciski: Pobierz Zadig / WinUSB oraz Uruchom Zadig.
- Dodano README_ZADIG_WINUSB.txt z instrukcją.
- libusb-1.0.dll traktowany jest jako opcjonalny, jeśli rtl_test/rtl_fm/rtlsdr.dll są obecne.


POPRAWKA v01.001.0062:
- „Uruchom Zadig” szuka teraz zadig*.exe w drivers, folderze programu, Downloads i Desktop.
- Dodano przycisk „Strona Zadig”.
- Skrypt pobierania Zadig ma fallbacki: link bezpośredni, parser katalogu, winget, otwarcie strony.
- Program kopiuje znaleziony plik do drivers/zadig.exe, jeśli może.


NOWE v01.001.0062:
- Auto-detect modulacji: WFM dla 87.5-108 MHz, AM dla lotnictwa, NFM domyślnie.
- Prosty waterfall tekstowy / poziom sygnału.
- Auto-tune do najsilniejszego sygnału w pobliżu aktualnej częstotliwości.
- Auto-restart audio po zmianie częstotliwości, modulacji, gain, squelch, PPM, sample/output rate.
- WFM automatycznie podbija sample rate do 170000 i output do 48000, żeby radio FM nie brzmiało jak szum.


NOWE v01.001.0062:
- widmo tekstowe / siła sygnału,
- osobny waterfall historii sygnału,
- profil pasma: automatycznie dobiera NFM/WFM/AM/USB/LSB, gain, squelch, sample rate i output rate,
- preset „PMR kanał 1 TX”,
- przyciski nie chowają się poza ekranem, panel sterowania używa WrapPanel,
- auto modulacja korzysta teraz z profilu pasma.


POPRAWKA v01.001.0062:
- Widmo i waterfall przeniesione do osobnej zakładki „Widmo / Waterfall”, żeby nie były ucięte na ekranie.
- Zwiększone okno startowe.
- Widmo ma teraz czytelniejszą skalę 0–100%.
- Historia waterfall trzyma więcej linii.


NOWE v01.001.0062:
- graficzne widmo SDR na Canvas,
- waterfall w stylu SDR++ / klasycznych analizatorów,
- skala dB po prawej,
- zielona siatka, żółta krzywa sygnału, niebiesko-żółto-czerwony waterfall,
- panel informacyjny po lewej,
- nadal jest to wizualizacja poziomu z rtl_fm, nie pełne FFT IQ. Pełne FFT wymaga kolejnego kroku: rtl_sdr/rtl_tcp + obróbka IQ.


POPRAWKA v01.001.0062:
- Naprawiono błąd kompilacji CS0104: Path był niejednoznaczny między System.IO.Path i System.Windows.Shapes.Path.
- Dodano alias IoPath dla System.IO.Path.
- Kontrolki graficzne Line/Rectangle/Polyline są kwalifikowane pełną przestrzenią nazw.


POPRAWKA v01.001.0062:
- Naprawiono ostatnie 2 błędy CS0246 dla Line w metodzie rysowania siatki widma.
- Wszystkie Line/Rectangle/Polyline są teraz kwalifikowane jako System.Windows.Shapes.*


NOWE v01.001.0062:
- Waterfall domyślnie zapisuje tylko wykryte aktywne sygnały, nie maluje bez sensu cały czas tej samej częstotliwości.
- Dodany checkbox „Waterfall tylko po wykryciu sygnału”.
- Przy braku aktywności waterfall pokazuje status „czekam na sygnał”.
- Poprawiony bufor audio: większy bufor NAudio, większy odczyt stdout, wygładzanie poziomu sygnału.
- PMR preset i PMR profile ustawiają 48 kHz/48 kHz dla stabilniejszego odsłuchu.
- Dodany plik docs/PROPOZYCJE_FICZEROW.txt.


NOWE v01.001.0062:
- Programowy filtr audio anti-pisk.
- Low-pass: ścina wysoki pisk/syczący ton.
- High-pass: usuwa dudnienie, DC i niskie zakłócenia.
- Noise gate: wycisza tło przy braku mowy/sygnału.
- Delikatny limiter przeciw trzaskom.
- Profile pasm automatycznie ustawiają filtry:
  PMR/NFM: LP 3200 Hz, HP 180 Hz
  AM: LP 4500 Hz, HP 120 Hz
  SSB: LP 3000 Hz, HP 250 Hz
  WFM: LP 15000 Hz, HP 60 Hz


NOWE v01.001.0062:
- Dodano zakładkę „Pomoc / O programie”.
- Dodano instrukcję obsługi programu.
- Dodano informację o twórcy: Heterodyna Team Software.
- Dodano link https://heterodyna.pl i przycisk otwierania strony.
- Dodano docs/POMOC_OBSLUGA.txt.


NOWE v01.001.0062:
- Zakładka „Funkcje PRO”.
- Banki częstotliwości: Radio FM, CB 40 AM, NOAA APT.
- Nagrywanie WAV: ciągłe albo tylko aktywny sygnał.
- Detektor aktywnych kanałów z eksportem TXT.
- Panel dekoderów cyfrowych: NOAA/APT, ADS-B, IoT/ISM.
- Folder recordings na nagrania.


NOWE v01.001.0062:
- Auto-tune ma wybór kierunku:
  • W dół
  • W górę
  • Oba kierunki
- Dodano krok auto-tune MHz.
- Dodano zakres auto-tune MHz.
- Dodano czas pomiaru na częstotliwość.
- Dodano przycisk Stop skan, który zatrzymuje Auto-tune oraz Auto-scan.


NOWE v01.001.0062:
- Auto Gain / AGC.
- AGC min/max gain i target poziomu sygnału.
- Status jakości sygnału: cisza / niski / dobry / mocny / PRZESTER.
- AGC automatycznie zmniejsza gain przy przesterze i podnosi przy słabym sygnale.
- Bezpieczny limit częstych zmian gain, żeby nie restartować rtl_fm zbyt agresywnie.


NOWE v01.001.0062:
- Dodano zakładkę Tryb Łatwy.
- Duże presety: Radio FM, PMR 446, Lotnictwo AM, CB 27 MHz, NOAA 137 MHz, Uniwersalny NFM.
- Presety automatycznie ustawiają modulację, gain, squelch, sample rate, output rate i filtry audio.
- Opcja automatycznego startu audio po wybraniu presetu.
- Opcja automatycznego włączenia AGC i filtra audio.


NOWE v01.001.0062:
- Zakładka Profile.
- Zapis aktualnych ustawień jako profil.
- Wczytanie profilu jednym kliknięciem.
- Usuwanie profili.
- Eksport/zapis do data/user-profiles.json.
- Dodano docs/PROFILE_UZYTKOWNIKA.txt.


NOWE v01.001.0062:
- Zakładka Kiwi SDR View.
- Widmo + waterfall + analiza + skaner w jednej zakładce.
- Kliknięcie w widmo stroi częstotliwość.
- Skan zakresu z HOLD na aktywnym sygnale.
- Log aktywnych częstotliwości.
- Panel analizy sygnału: poziom, typ, aktywność, RX.


POPRAWKA v01.001.0062:
- Naprawiono błąd kompilacji CS0246 dla MouseButtonEventArgs.
- Dodano using System.Windows.Input; po dodaniu kliknięcia w widmo Kiwi SDR View.


POPRAWKA v01.001.0062:
- Naprawiono brakujące pola po integracji funkcji Profile / AGC / Kiwi SDR View.
- Dodano brakujące _profilesFile, _userProfiles, _lastAgcChangeAt, _agcStableTicks.
- Dodano fallback kontrolki SpectrumClickSpanBox dla kliknięcia w widmo Kiwi.


NOWE v01.001.0062:
- FFT / IQ PRO.
- Realny odczyt IQ przez rtl_sdr.exe.
- FFT 1024.
- Realny waterfall IQ.
- Nagrywanie IQ .u8.iq.


NOWE v01.001.0062:
- Skan siły sygnału.
- dBm/SNR/audio RMS/AGC audio w UI.
- Wyrównanie głośności audio.
- Zakładka Wartości sterowania z opisem parametrów.


NOWE v01.001.0062:
- Naprawiono błąd kompilacji: brakujące kontrolki AGC audio w XAML.
- Dodano README_WARTOSCI_PASM.md z tabelą zalecanych ustawień dla PMR, lotnictwa, FM, ADS-B, CB, APRS, AIS.
- Dodano bezpieczne wartości domyślne AGC audio: target -18 dBFS, min 20%, max 100%.


POPRAWKA v01.001.0062:
- Usunięto problem wielu plików .csproj w katalogu.
- W paczce zostaje jeden projekt: HeterodynaSDRScanner_v01.001.0062.csproj
- Dodano URUCHOMIENIE.txt z dokładnymi komendami.


POPRAWKA v01.001.0062:
- Naprawiono brak dźwięku: Audio loop nie czyta już kontrolek WPF z wątku audio.
- Parametry filtrów i AGC audio są pobierane bezpiecznie przez Dispatcher, a obróbka audio działa poza wątkiem UI.
- Poprawka błędu: „Wątek wywołujący nie może uzyskać dostępu do tego obiektu...”.


NOWE v01.001.0062:
- Radio / skaner = główny dashboard PRO na wzór ostatniego screena.
- Tryb Łatwy i reszta zakładek zostały zachowane z bazy projektu.
- Startowo otwiera się zakładka Radio / skaner.
- Układ: top status, kanały, sterowanie, miernik, FFT/waterfall, AGC/DSP/głośność, logi i wskazówki.
